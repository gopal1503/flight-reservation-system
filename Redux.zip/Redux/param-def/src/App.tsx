import React from "react";

import "./App.css";
import ParamForm from "./components/ParamInputs";

function App() {
  return (
    <div className="App">
      <ParamForm />
    </div>
  );
}

export default App;
