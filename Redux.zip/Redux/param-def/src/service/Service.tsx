import axios from "axios";

const BASEURL = "http://localhost:8080/Param";

export const API = {
  postParam: async (data: any) => {
    const postParam = await axios.post(`${BASEURL}/post`, data);
    return postParam.data;
  },
};
