import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addParam } from "./ParamDef";
import * as yup from "yup";

const ParamForm: React.FC = () => {
  const dispatch = useDispatch();

  const [paramCode, setParamCode] = useState("");
  const [paramDesc, setParamDesc] = useState("");
  const [paramValue, setParamValue] = useState("");

  const paramValidation = yup.object().shape({
    param_code: yup.string().required(),
    param_desc: yup.string().required(),
    param_value: yup.string().required(),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const param = {
      param_code: paramCode,
      param_desc: paramDesc,
      param_value: paramValue,
    };
    const isValidate = paramValidation.isValid(param);
    console.log(isValidate);
    dispatch(addParam(param));

    // Reset input fields
    setParamCode("");
    setParamDesc("");
    setParamValue("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Param Code:</label>
        <input
          type="text"
          value={paramCode}
          onChange={(e) => setParamCode(e.target.value)}
          placeholder="Param Code"
        />
      </div>
      <div>
        <label>Param Description:</label>
        <input
          type="text"
          value={paramDesc}
          onChange={(e) => setParamDesc(e.target.value)}
          placeholder="Param Description"
        />
      </div>
      <div>
        <label>Param Value:</label>
        <input
          type="text"
          value={paramValue}
          onChange={(e) => setParamValue(e.target.value)}
          placeholder="Param Value"
        />
      </div>
      <button type="submit">Add Param</button>
    </form>
  );
};

export default ParamForm;
