import { createSlice, PayloadAction, Dispatch } from "@reduxjs/toolkit";
import { API } from "../service/Service";

interface Param {
  param_code: string;
  param_desc: string;
  param_value: string;
}

interface ParamState {
  value: Param;
}

const initialState: ParamState = {
  value: { param_code: "", param_desc: "", param_value: "" },
};

const paramSlice = createSlice({
  name: "slice",
  initialState,
  reducers: {
    addParam: (state, action) => {
      //   const param: Param = action.payload;
      state.value = action.payload;
      API.postParam(state.value).then((res) => {});
    },
  },
});

export const { addParam } = paramSlice.actions;
export default paramSlice.reducer;

// export const postParam = (param: Param) => async (dispatch: Dispatch<any>) => {
//   try {
//     const res = await API.postParam(param);
//     dispatch(addParam(res.data));
//     alert("Values added");
//   } catch (error) {
//     // Handle error
//     console.error("Error adding param:", error);
//   }
// };
