package com.example.demo.Dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.Bean.Student;
@Repository
public class StudentDao {
@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	private Query<Student> q;
	
	public ArrayList<Student> viewStudent(){
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		q=session.createQuery("from Student");
		return (ArrayList<Student>) q.list();
		
	}
	public String addStudent(Student student) {
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		session.save(student);
		transaction.commit();
		session.close();
		return "SUCCESS";
	}
}

