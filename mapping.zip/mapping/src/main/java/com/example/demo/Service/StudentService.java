package com.example.demo.Service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Bean.Student;
import com.example.demo.Dao.StudentDao;
@Service
public class StudentService {
@Autowired
private StudentDao adao;

public ArrayList<Student> viewStudent(){
	return adao.viewStudent();
}
public String addStudent(Student student) {
	return adao.addStudent(student);
}

}
