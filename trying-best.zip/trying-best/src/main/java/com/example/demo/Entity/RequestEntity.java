package com.example.demo.Entity;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class RequestEntity {

	private List<String> queries;

	public List<String> getQueries() {
		return queries;
	}

	public void setQueries(List<String> queries) {
		this.queries = queries;
	}
	
	
}
