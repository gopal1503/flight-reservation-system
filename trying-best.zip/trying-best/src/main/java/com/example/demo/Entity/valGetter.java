package com.example.demo.Entity;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "vr_tb_tbl1")
@Component
@Configuration
public class valGetter {
	
	@Id
	@GeneratedValue
	private Integer valId;
	
	private String query;

	public Integer getValId() {
		return valId;
	}

	public void setValId(Integer valId) {
		this.valId = valId;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

}
