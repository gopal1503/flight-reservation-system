package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.RequestEntity;

@RestController
@RequestMapping("/do")
public class RequestController {

	@Autowired
	private RequestEntity ren;
	@PostMapping("/post")
	public List<String> get(){
		return ren.getQueries();
	}
}
