package com.example.demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ServiceImpl.QueryServiceImpl;

@RestController
@RequestMapping("/query")
@CrossOrigin("http://localhost:3000")
public class QueryController {
	
	@Autowired
	private QueryServiceImpl qimpl;
	@PostMapping("/get")
	public ResponseEntity<Object> getData(){
		return qimpl.getData();
	}

}
