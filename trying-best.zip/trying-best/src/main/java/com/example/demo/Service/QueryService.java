package com.example.demo.Service;

import java.util.List;


import org.springframework.http.ResponseEntity;


public interface QueryService {
	public ResponseEntity<Object> getData(); 
		   
}
