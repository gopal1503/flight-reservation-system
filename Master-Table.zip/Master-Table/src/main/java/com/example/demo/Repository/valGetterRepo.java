package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.valGetter;
@Repository
public interface valGetterRepo extends JpaRepository<valGetter, Integer> {

}
