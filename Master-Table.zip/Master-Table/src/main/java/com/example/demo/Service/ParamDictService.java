package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.ParamDictRepository;
import com.example.demo.model.ParamDict;

@Service
public class ParamDictService {
	@Autowired
	private ParamDictRepository dictRepo;
	
	public List<ParamDict> getAll(ParamDict param){
		if(param!=null) {return dictRepo.findAll();}
		else {
			return null;
	}
	}
	
	public ParamDict addDict(ParamDict param) {
		return dictRepo.save(param);
	}
	
	
	public Optional<ParamDict> getById(int id){
		return dictRepo.findById(id);   
	}
	
	public ParamDict deleteDict(int ParamDict) {
		Optional<ParamDict> dict=dictRepo.findById(ParamDict);{
			if(dict.isPresent()) {
				dictRepo.delete(dict.get());
				return dict.get();
			}else {
				return null;
			}
		}
	}
}
