package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.stateService;
import com.example.demo.model.ParamState;

@RestController
@RequestMapping("/state")
@CrossOrigin("http://localhost:3000")
public class stateController {
@Autowired
private stateService sserv;
@GetMapping("/get")
public List<ParamState> getAll(){
return sserv.getAll();
}
@PostMapping("/post")
public ParamState addState(@RequestBody ParamState param) {
return sserv.addState(param);
}

@GetMapping("/getByState/{state}")
public List<ParamState> getAllByState(@PathVariable( value="state") String state){
	return sserv.getAllByState(state);
}
@GetMapping("/ByDoc/{doc}")
public Optional<ParamState>getByDoc(@PathVariable( value="doc")int Docid) {
	return sserv.getByDoc(Docid);
}
@GetMapping("/ByScreen/{screen}")
public Optional<ParamState> getByScreen(@PathVariable( value="screen")String screen){
	return sserv.getByScreen(screen);
}

@GetMapping("/ByState")
public ParamState getByState(String state) {
	return sserv.getByState(state);
}

//@GetMapping("ByState/{stateName}")
//public ResponseEntity<ParamState> getByState(@PathVariable ( value="stateName") String stateName) {
//    ParamState paramState = sserv.getByState(stateName);
//    if (paramState == null) {
//        return ResponseEntity.notFound().build();
//    } else {
//        return ResponseEntity.ok(paramState);
//    }
//}
@GetMapping("/onlyState")
public List<String> getStateNames(){
	return sserv.getStateNames();
}
@GetMapping("/onlyScreen")
public List<String> getScreen(){
	return sserv.getScreen();
}
@PutMapping("/update")
public ParamState updateState(@RequestBody ParamState param) {
return sserv.updateState(param);
}
@GetMapping("byid/{id}")
public Optional<ParamState> stateById(@PathVariable( value="id")int stateId){
	return sserv.stateById(stateId);
}
@DeleteMapping("/delete/{id}")
public ParamState deleteState(@PathVariable( value="id")int stateid) {
return sserv.deleteState(stateid);
}
}
