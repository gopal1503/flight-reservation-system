package com.example.demo.QueryServiceImpl;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;

@Service
public class QueryServiceImpl implements com.example.demo.Service.QueryService {

    @Autowired
    EntityManager entityManager;

    @Override
    @Scheduled(cron = "0 17 12 * * ?")
    public ResponseEntity<Object> getData(List<String> queries) {
        List<Map<String, Object>> resultList = new ArrayList<>();
        Map<String, Object> responseMap = new HashMap<>();
        byte[] excelBytes = null; // Initialize excelBytes variable

        try (Connection connectionObject = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=gopal", "Gopal", "root")) {
            int sheetIndex = 0;

            for (String query : queries) {
                try (Statement statementObject = connectionObject.createStatement();
                     ResultSet resultSet = statementObject.executeQuery(query)) {

                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();

                    List<Map<String, String>> dataMapList = new ArrayList<>();
                    while (resultSet.next()) {
                        Map<String, String> dataMap = new HashMap<>();
                        for (int columnNum = 1; columnNum <= columnCount; columnNum++) {
                            String columnName = metaData.getColumnName(columnNum).isEmpty() ? "column" + columnNum
                                    : metaData.getColumnName(columnNum);
                            String columnValue = resultSet.getString(columnNum);
                            dataMap.put(columnName, columnValue);
                        }
                        dataMapList.add(dataMap);
                    }

                    Map<String, Object> sheetData = new HashMap<>();
                    String sheetName = "Sheet " + (sheetIndex + 1);
                    sheetData.put("sheetName", sheetName);
                    sheetData.put("data", dataMapList);
                    resultList.add(sheetData);
                    sheetIndex++;
                } catch (Exception exception) {
                    responseMap.put("responseCode", "1");
                    responseMap.put("responseMessage", "SQL Query Execution Failed");
                    responseMap.put("exception", exception.getMessage());
                }
            }

            if (resultList.isEmpty()) {
                responseMap.put("responseCode", "1");
                responseMap.put("responseMessage", "No data available for the query");
            } else {
                // Create Excel workbook and sheets
                Workbook workbook = new XSSFWorkbook();
                for (Map<String, Object> sheetData : resultList) {
                    String sheetName = (String) sheetData.get("sheetName");
                    List<Map<String, String>> dataMapList = (List<Map<String, String>>) sheetData.get("data");

                    Sheet sheet = workbook.createSheet(sheetName);
                    int rowIdx = 0;
                    for (Map<String, String> dataMap : dataMapList) {
                        Row row = sheet.createRow(rowIdx++);
                        int cellIdx = 0;
                        for (Map.Entry<String, String> entry : dataMap.entrySet()) {
                            String columnName = entry.getKey();
//                            System.out.println(columnName);
                            String columnValue = entry.getValue();

                            Cell cell = row.createCell(cellIdx++);
                            cell.setCellValue(columnValue);

                            // Create a cell style and set the cell's value to include the key as well
                            CellStyle style = workbook.createCellStyle();
                            RichTextString richText = new XSSFRichTextString(columnName + ": " + columnValue);
                            cell.setCellValue(richText);
                            cell.setCellStyle(style);
                            System.out.print(cell);
                        }
                    }
                }

                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                excelBytes = outputStream.toByteArray();
            }

        } catch (Exception exception) {
            responseMap.put("responseCode", "1");
            responseMap.put("responseMessage", "SQL Query Execution Failed");
            responseMap.put("exception", exception.getMessage());
        }

        if (excelBytes != null) {
            // Create and return file download response
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
            headers.setContentDispositionFormData("attachment", "data.xlsx");
            return ResponseEntity.ok()
                    .headers(headers)
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(excelBytes);
        } else {
            // Return JSON response
            responseMap.put("responseCode", "0");
            return ResponseEntity.ok().body(responseMap);
        }
    }


}