package com.example.demo.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.ParamState;

public interface stateRepository extends JpaRepository<ParamState, Integer>{

	
	@Query("select g from ParamState g where  g.StateName=:stateName")
	public List<ParamState> getAllByState(@Param(value = "stateName") String stateName);

	@Query("select s from ParamState s where s.paramDict.document_grp_id=:docId")
	public Optional<ParamState> getByDocId(@Param (value="docId")int docId);

	@Query("select d from ParamState d where d.paramDict.screen_code=:screen")
	public Optional<ParamState> getByScreen(@Param (value="screen")String screen);
	
	@Query(value = "SELECT * FROM state_tab WHERE state_name = ?", nativeQuery = true)
	public ParamState getByState(String stateName);

	@Query(value = "SELECT state_name FROM state_tab", nativeQuery = true)
	public List<String> getStateNames();
	
	@Query(value="SELECT document_grp_id from state_tab", nativeQuery = true)
	public List<String> getScreen();

	
	
}

