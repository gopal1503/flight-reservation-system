package com.example.demo.model;

import org.springframework.web.bind.annotation.CrossOrigin;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="vr_tb_document_grp_dict")

public class ParamDict {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int document_grp_id;

@Column
private String doc_grp_description;

@Column
private String screen_code;
@Column
private String const_appl_ind;

@Column
private String subgl_appl;

public ParamDict() {
	super();
}

public int getDocument_grp_id() {
	return document_grp_id;
}

public void setDocument_grp_id(int document_grp_id) {
	this.document_grp_id = document_grp_id;
}

public String getDoc_grp_description() {
	return doc_grp_description;
}

public void setDoc_grp_description(String doc_grp_description) {
	this.doc_grp_description = doc_grp_description;
}

public String getScreen_code() {
	return screen_code;
}

public void setScreen_code(String screen_code) {
	this.screen_code = screen_code;
}

public String getConst_appl_ind() {
	return const_appl_ind;
}

public void setConst_appl_ind(String const_appl_ind) {
	this.const_appl_ind = const_appl_ind;
}

public String getSubgl_appl() {
	return subgl_appl;
}

public void setSubgl_appl(String subgl_appl) {
	this.subgl_appl = subgl_appl;
}




}
