package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.ParamService;
import com.example.demo.model.ParameterDef;

@RestController
@RequestMapping("/Param")
@CrossOrigin("http://localhost:3000")
public class ParamController {
	@Autowired
	private ParamService pserv;
	@GetMapping("/get")
	public List<ParameterDef> getAll(){
		return pserv.getAll();
	}
	@PostMapping("/post")
	public ParameterDef addParam(@RequestBody ParameterDef  param){
	return pserv.addParam(param);
	}
@PutMapping("/update")
	public ParameterDef updateParam(@RequestBody ParameterDef param) {
return pserv.updateParam(param);

}           
@GetMapping("/byid/{id}")
public Optional<ParameterDef> getById(@PathVariable (value="id")int param){
	return pserv.getById(param);
}
@DeleteMapping("/dbyid/{id}")
public ParameterDef deleteById(@PathVariable (value="id")int id) {
	return pserv.deleteById(id);
}
	
}


