package com.example.demo.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="state_tab")
public class ParamState {
@Id
@GeneratedValue
private int StateId;
@Column
private String StateName;

@ManyToOne
@JoinColumn(name="document_grp_id")
private ParamDict paramDict;

public ParamState() {
	super();
}

public int getStateId() {
	return StateId;
}

public void setStateId(int stateId) {
	StateId = stateId;
}

public String getStateName() {
	return StateName;
}

public void setStateName(String stateName) {
	StateName = stateName;
}

public ParamDict getParamDict() {
	return paramDict;
}

public void setParamDict(ParamDict paramDict) {
	this.paramDict = paramDict;
}


}
