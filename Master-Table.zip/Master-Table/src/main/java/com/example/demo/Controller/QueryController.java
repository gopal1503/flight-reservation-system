package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.QueryServiceImpl.QueryServiceImpl;

@RestController
@RequestMapping("/query")
@CrossOrigin("http://localhost:3000")
public class QueryController {

    @Autowired
    private QueryServiceImpl queryService;

    @PostMapping(value = "/get", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<Object> executeQuery() {
//        // Execute the scheduled queries and handle the response
//        queryService.executeScheduledQuery();
//        
//        // TODO: Modify the response based on your requirements
//        // For example, you can return a success message or appropriate HTTP status code
//        return ResponseEntity.ok("Scheduled queries executed successfully");
//    }
    public ResponseEntity<Object> get(List<String> queries){
    	return queryService.getData(queries);
    }
}
