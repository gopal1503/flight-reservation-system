package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="vr_tb_parameter_defn")
public class ParameterDef {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)
private int param_id;

@Column
private String param_code;
@Column 
private String param_desc;

@Column
private String param_value;

public ParameterDef() {
	super();
}

public int getParam_id() {
	return param_id;
}

public void setParam_id(int param_id) {
	this.param_id = param_id;
}

public String getParam_code() {
	return param_code;
}

public void setParam_code(String param_code) {
	this.param_code = param_code;
}

public String getParam_desc() {
	return param_desc;
}

public void setParam_desc(String param_desc) {
	this.param_desc = param_desc;
}

public String getParam_value() {
	return param_value;
}

public void setParam_value(String param_value) {
	this.param_value = param_value;
}


}
