package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.stateRepository;
import com.example.demo.model.ParamState;

@Service
public class stateService {
@Autowired
private stateRepository srepo;

public List<ParamState> getAll(){
	return srepo.findAll();
}

public ParamState addState(ParamState param) {
	return srepo.save(param);
}

public List<ParamState> getAllByState(String state){
	return srepo.getAllByState(state);
}

public Optional<ParamState>getByDoc(int Docid) {
	return srepo.getByDocId(Docid);
}

public Optional<ParamState> getByScreen(String screen){
	return srepo.getByScreen(screen);
}

public ParamState getByState(String state) {
	return srepo.getByState(state);
}
public List<String> getStateNames(){
	return srepo.getStateNames();
}
public List<String> getScreen(){
	return srepo.getScreen();
}

public ParamState updateState(ParamState param) {
	if(param!=null) {
		return srepo.save(param);
	}else {
		return null;
	}
}

public ParamState deleteState(int stateid) {
	Optional<ParamState> param=srepo.findById(stateid);
	if(param.isPresent()) {
		 srepo.delete(param.get());
		 return param.get();
	}else {
		
	
	return null;
}
	

}
public Optional<ParamState> stateById(int stateId){
	return srepo.findById(stateId);
}

}



