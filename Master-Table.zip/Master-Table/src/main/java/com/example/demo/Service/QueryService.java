package com.example.demo.Service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;

public interface QueryService {
	public ResponseEntity<Object> getData(List<String> requestBody); 
		   
}
