package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.paramRepo;
import com.example.demo.model.ParameterDef;

@Service
public class ParamService {
	@Autowired
	private paramRepo prepo;
	
	public List<ParameterDef> getAll(){
		return prepo.findAll();
	}
	
	public ParameterDef addParam(ParameterDef  param){
		return prepo.save(param);
	}
	
	public ParameterDef updateParam(ParameterDef param) {
	    if (param != null) {
	        return prepo.save(param);
	    } else {
	        return null;
	    }
	}

	public Optional<ParameterDef> getById(int param){
		return prepo.findById(param);
	}
	
	public ParameterDef deleteById(int id) {
		Optional<ParameterDef> param=prepo.findById(id);
		if(param.isPresent()) {
			 prepo.delete(param.get());
			return param.get();
		}else {
			return null;
		}
	}


}
