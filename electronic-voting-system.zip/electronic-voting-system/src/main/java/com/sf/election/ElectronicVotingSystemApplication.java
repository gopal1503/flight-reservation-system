package com.sf.election;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectronicVotingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectronicVotingSystemApplication.class, args);
	}

}
