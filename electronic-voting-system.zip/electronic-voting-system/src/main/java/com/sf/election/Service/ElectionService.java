package com.sf.election.Service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sf.election.Bean.ElectionBean;
import com.sf.election.Dao.ElectionDao;

@Service
public class ElectionService {
@Autowired
private ElectionDao adao;
public String addElection(ElectionBean electionBean) 
{
	return adao.addElection(electionBean);
}
public ArrayList<ElectionBean> viewElections()
{
	return adao.viewElections();
}
public String updateElection(ElectionBean electionBean)
{
	return adao.updateElection(electionBean);
}
public String deleteElection(int electionId)
{
	return adao.deleteElection(electionId);
}
public ElectionBean viewElectionById(int electionId)
{
	return adao.viewElectionById(electionId);
}

}
