package com.sf.election.Dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sf.election.Bean.ElectionBean;
@Repository
public class ElectionDao {
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	private Query<ElectionBean> q; 
	public String addElection(ElectionBean electionBean) 
	{
		if(electionBean!=null)
		{
			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			session.save(electionBean);
			transaction.commit();
			session.close();
			return "SUCCESS";
		}
		else if(electionBean==null)
		{
			return "ERROR";
		}
		else
		{
			return "FAIL";
		}
	}
	
	public String updateElection(ElectionBean electionBean)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(electionBean!=null)
		{
		session.update(electionBean);

		transaction.commit();

		session.close();
		return "SUCCESS";
		}
		else if(electionBean==null)
		{
			return "FAIL";
		}
		else
		{
			return "ERROR";
		}
	}
	public String deleteElection(int electionId)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(electionId>=0)
		{
		Query q1=session.createQuery("delete from ElectionBean where electionID=:eid");
		q1.setParameter("eid", electionId);
		q1.executeUpdate();
transaction.commit();
session.close();
		return "SUCCESS";
		}
		else
		{
			return "FAIL";
		}
	}
	public ArrayList<ElectionBean> viewElections()
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		q=session.createQuery("from ElectionBean");
		return (ArrayList<ElectionBean>) q.list();
	}
	public ElectionBean viewElectionById(int electionId)
	{
		ElectionBean elBean=new ElectionBean();
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
	Query<ElectionBean> q2=session.createQuery("from ElectionBean where electionID=:eid");
	q2.setParameter("eid", electionId);
	ArrayList<ElectionBean> all=(ArrayList<ElectionBean>) q2.getResultList();
	for(ElectionBean e1:all)
	{
		elBean=e1;
	}
	return elBean;
	}
}
