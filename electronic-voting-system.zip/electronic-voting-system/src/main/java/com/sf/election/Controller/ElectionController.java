package com.sf.election.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sf.election.Bean.ElectionBean;
import com.sf.election.Service.ElectionService;

@RestController
@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/admin")
public class ElectionController {
	@Autowired
	private ElectionService adserv;
@PostMapping("/addElection")
public String meth1(@RequestBody ElectionBean eb)
{
	adserv.addElection(eb);
	return "<h1>Election Added Successfully</h1>";
}
@GetMapping("/selectAll")
public List<ElectionBean> meth2()
{
	
	return adserv.viewElections();
}
@PutMapping("/updateElection")
public String meth3(@RequestBody ElectionBean eb)
{
	adserv.updateElection(eb);
	return "<h1> Election Updated successfully</h1>";
}
@GetMapping("/election/{id}")
public ElectionBean meth4(@PathVariable(value = "id") int electionId)
{
	return adserv.viewElectionById(electionId);
	
}
@DeleteMapping("/deleteElection/{id}")
public String meth5(@PathVariable(value="id") int electionId)
{
	return "<h1>"+adserv.deleteElection(electionId)+" record deleted successfully</h1>";
}
}
