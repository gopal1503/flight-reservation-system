package com.example.demo.Bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
  @Id
  @GeneratedValue
  private int customer_Id;
  @Column
  private String customerName;
  @Column
  private String contactNumber;
  @Column
  private String customerMail;
  
  
  
public Customer() {
	
}
public int getCustomer_Id() {
	return customer_Id;
}
public void setCustomer_Id(int customer_Id) {
	this.customer_Id = customer_Id;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getCustomerMail() {
	return customerMail;
}
public void setCustomerMail(String customerMail) {
	this.customerMail = customerMail;
}
  
}
