	
	package com.example.demo.Service;

	import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.data.domain.Example;
	import org.springframework.stereotype.Service;

	import com.example.demo.Bean.Customer;
	import com.example.demo.Repository.CustomerRepository;

	@Service
	public class CustomerService {

		@Autowired
		private CustomerRepository cusrepo;
		
		public List<Customer> getAllCustomers() {
			return cusrepo.findAll();
		}
		
	
		
	}
	

