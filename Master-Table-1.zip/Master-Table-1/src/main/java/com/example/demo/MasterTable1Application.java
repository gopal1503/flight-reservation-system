package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterTable1Application {

	public static void main(String[] args) {
		SpringApplication.run(MasterTable1Application.class, args);
	}

}
