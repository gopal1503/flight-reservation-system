package com.example.demo.Service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.EmployyeRepository;
import com.example.demo.model.EmployeeBean;
import org.springframework.jdbc.core.JdbcTemplate;


@Service
public class EmployeeService {
	@Autowired
	private EmployyeRepository erepo;
	
//	public List<EmployeeBean> getAll(){
//		return erepo.findAll();
//	}
	
	public EmployeeBean addEmployee(EmployeeBean employee) {
		return erepo.save(employee);
	}
	
	public List<EmployeeBean> getEmployee() {
	    String query = "select*from employee";
	    if (query.equals("select*from employee")) {
	        return erepo.getEmployee();
	    } else {
	        return null;
	    }
	}
	
    public List<String> first(){
    	return erepo.first();
    }
    
    
    public List<String> getName(String firstName) {
        String query = "SELECT * FROM Employee WHERE first_Name = ?";
        if (query.equals("SELECT * FROM Employee WHERE first_Name = ?")) {
            return erepo.getUniqueNames(firstName);
        } else {
            return Collections.singletonList("error");
        }
    }





	}
	

	


