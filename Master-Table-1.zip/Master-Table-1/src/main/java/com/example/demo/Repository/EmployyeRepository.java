package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.EmployeeBean;

@Repository
public interface EmployyeRepository extends JpaRepository<EmployeeBean, Long> {
    @Query(value = "SELECT e FROM EmployeeBean e")
    public List<EmployeeBean> getEmployee();
    
    
    @Query(value="select first_Name from Employee",nativeQuery = true)
    public List<String> first();

    
    
    @Query(value = "SELECT * FROM Employee WHERE first_Name = :firstName", nativeQuery = true)
    public List<String> getUniqueNames(@Param("firstName") String firstName);


}
