package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.EmployeeService;

import java.util.List;

@RestController
public class EmployeeController {
    private EmployeeService eserv;

    // Constructor
    @Autowired
    public EmployeeController(EmployeeService eserv) {
        this.eserv = eserv;
    }

    @GetMapping("/name")
    public List<String> getNames(@RequestParam String query) {
        if (query.equalsIgnoreCase("SELECT * FROM Employee WHERE first_Name = ?")) {
            return eserv.getName(query);
        } else {
            return null;
        }
    }

    // Other controller methods...
}
