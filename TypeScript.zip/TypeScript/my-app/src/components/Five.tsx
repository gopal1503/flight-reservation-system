import React from "react";
import Four from "./Four";

function Five(props: any) {
  const {
    handleSubmit,
    handleChange,
    param_code,
    param_desc,
    param_value,
    data,
  } = props;

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          id={param_code}
          value={data.param_code}
          onChange={handleChange}
        ></input>
        <input
          id={param_desc}
          value={data.param_desc}
          onChange={handleChange}
        ></input>
        <input
          id={param_value}
          value={data.param_value}
          onChange={handleChange}
        ></input>
        <button type="submit">submit</button>
      </form>
    </div>
  );
}

export default Five;
