import React from 'react';

class A {
  name: string;
  status: boolean;
  age: number;

  constructor() {
    this.name = "gokul";
    this.status = true;
    this.age = 23;
  }
}

const instanceOfA = new A();
console.log(instanceOfA);

function Second() {
  return (
    <div>
      
    </div>
  );
}

export default Second;
