import React from "react";

class Employee {
  private id: number;
  public name: string;
  private mail: string;
  private department: string;

  constructor(id: number, n: string, m: string, d: string) {
    this.id = id;
    this.name = n;
    this.mail = m;
    this.department = d;
  }

  protected details(): string {
    return `id=${this.id} name=${this.name} mail=${this.mail} department=${this.department}`;
  }
}

class Trainee extends Employee {
  private work: string;

  constructor(id: number, n: string, m: string, d: string) {
    super(id, n, m, d);
    this.work = "Trainee Work";
  }

  public maindetails(): void {
    console.log(this.details());
  }
}

function Third() {
  const employee = new Employee(101, "John Doe", "john.doe@example.com", "Sales");
  const trainee = new Trainee(201, "Jane Smith", "jane.smith@example.com", "Marketing");

  console.log(employee);
  trainee.maindetails();

  return <div></div>;
}

export default Third;
