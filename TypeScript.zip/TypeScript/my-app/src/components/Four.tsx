import React, { useState } from "react";
import { API } from "../service/service";

function Four() {
  const [data, setData] = useState({
    param_code: "",
    param_desc: "",
    param_value: "",
  });

  const handleChange = (e: any) => {
    e.preventDefault();
    setData({ ...data, [e.target.id]: e.target.value });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    API.postParam(data).then((res) => {
      alert(res);
    });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input id="param_code" onChange={handleChange}></input>
        <input id="param_desc" onChange={handleChange}></input>
        <input id="param_value" onChange={handleChange}></input>
        <button>ADD</button>
      </form>
    </div>
  );
}

export default Four;
