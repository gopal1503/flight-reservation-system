import React from "react";

function First() {
  const firstName = "gokul";
  console.log(typeof firstName);

  const randomOne = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"];

  let randomValue = '';
  for (let i = 0; i < 10; i++) {
    randomValue = randomOne[Math.floor(Math.random() * randomOne.length)];
    console.log(randomValue);
  }

  return (
    <div>
      <p>{randomValue}</p>
    </div>
  );
}

export default First;
