import React from 'react';
import logo from './logo.svg';
import './App.css';
import First from './components/First';
import Second from './components/Second';
import Third from './components/Third';
import Four from './components/Four';
import Five from './components/Five';

function App() {
  return (
    <div className="App">
      {/* <First/>
      <Second/>
      <Third/> */}
      <Four/>
      <Five/>
    </div>
  );
}

export default App;
