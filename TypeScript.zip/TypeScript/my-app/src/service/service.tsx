import axios, { AxiosResponse } from "axios";

const BASEURL = "http://localhost:8080/Param";

interface PostData {
  // Define the structure of the data object being passed in the request
  // Modify the properties according to your specific data structure
  param_code: string;
  param_desc: string;
  param_value: string;
}

export const API = {
  postParam: async (data: PostData): Promise<AxiosResponse> => {
    try {
      const response: AxiosResponse = await axios.post(`${BASEURL}/post`, data);
      return response.data;
    } catch (error) {
      // Handle the error if needed
      console.error("An error occurred:", error);
      throw error;
    }
  },
};
