import React from "react";
import "../App.css";

export default function Footer() {
  return (
    <div className="foot">
      <footer>&copy; Sundaram Infotech Solutions</footer>
    </div>
  );
}
