import React, { useEffect, useState } from "react";
import { API } from "../service/Service";
import "bootstrap/dist/css/bootstrap.min.css";

function GetCustomers() {
  const [customer, setCustomer] = useState([]);
  const [employee, setEmployee] = useState([]);
  const [selectedOption, setSelectedOption] = useState("");

  const handleChange = (e) => {
    setSelectedOption(e.target.value);
  };

  useEffect(() => {
    API.getCustomers().then((res) => {
      setCustomer(res.data);
    });
  }, []);

  useEffect(() => {
    API.getEmployees().then((res) => {
      setEmployee(res.data);
    });
  }, []);

  return (
    <div>
      <select onChange={handleChange}>
        <option value="">--select option--</option>
        <option value="customer">customer details</option>
        <option value="employee">employee details</option>
      </select>
      {selectedOption === "customer" && (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>CUSTOMER ID</th>
              <th>CONTACT NAME</th>
              <th>CUSTOMER NO</th>
              <th>CUSTOMER MAIL</th>
            </tr>
          </thead>
          <tbody>
            {customer.map((cus) => {
              return (
                <tr key={cus.cutomer_Id}>
                  <td>{cus.customer_Id}</td>
                  <td>{cus.customerName}</td>
                  <td>{cus.contactNumber}</td>
                  <td>{cus.customerMail}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
      {selectedOption === "employee" && (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>EMPLOYEE ID</th>
              <th>EMPLOYEE NAME</th>
              <th>CONTACT NO</th>
            </tr>
          </thead>
          <tbody>
            {employee.map((emp) => {
              return (
                <tr key={emp.employeeId}>
                  <td>{emp.employeeId}</td>
                  <td>{emp.employeeName}</td>
                  <td>{emp.contactNumber}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default GetCustomers;
