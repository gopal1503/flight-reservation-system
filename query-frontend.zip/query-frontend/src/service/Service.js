import axios from "axios";

const BASEURL = "http://localhost:8777/customer";
const BASEURL1 = "http://localhost:8777/employee";

export const API = {
  getCustomers: async () => {
    const getCustomers = await axios.get(`${BASEURL}/viewCustomers`);
    return getCustomers;
  },

  getEmployees: async () => {
    const getEmployees = await axios.get(`${BASEURL1}/viewEmployee`);
    return getEmployees;
  },
};
