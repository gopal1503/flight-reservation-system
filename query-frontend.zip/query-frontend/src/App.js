import './App.css';
import GetCustomers from './components/GetCustomers';

function App() {
  return (
    <div className="App">
      <GetCustomers/>
    </div>
  );
}

export default App;
