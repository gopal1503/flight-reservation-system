package com.example.demo.Bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="department")
public class DepartmentBean {
	@Id
	@GeneratedValue
	private int depId;
	@Column
	private String depName;
	@Column
	private String depHod;
	
	

}
